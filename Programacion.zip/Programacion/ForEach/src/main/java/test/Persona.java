
package test;


public class Persona {
    //atributos
    private String nombre;
    //constructor
    public Persona(String nombre) {
        this.nombre = nombre;
    }
    //metodos

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Perdsona{nombre=").append(nombre);
        sb.append('}');
        return sb.toString();
    }
    

    
    
    
}
