
package test;


public class TestForEach {

    
    public static void main(String[] args) {
        int edades[] = {5,4,3,2,1,6};
        Persona personas[] = {new Persona("emilio"), new Persona("matias"), new Persona("Saldivar"),new Persona("Caputo")};
        
        for(Persona persona: personas){
            System.out.println("persona = " + persona);
        }
        for(int edad: edades){
            System.out.println("edad: " + edad);
        }
    }
    
}
