
package paquete1;


public class Clase1 {
    private String atributoPublico = "atributo publico";
    protected String atributoProtegidoDelPaquete="jajajajajaja";

    public Clase1() {
    }
    public void metodoPublico(){
        System.out.println("Se ejecuta el metodo publico");
    }
    public String getAtributoPublico() {
        return this.atributoPublico;
    }

    public void setAtributoPublico(String atributoPublico) {
        this.atributoPublico = atributoPublico;
    }
    
    
    
}
