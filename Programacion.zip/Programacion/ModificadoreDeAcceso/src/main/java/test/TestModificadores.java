
package test;

import paquete1.Clase1;


public class TestModificadores {
    Clase1 calse1 = new Clase1();
    
}
