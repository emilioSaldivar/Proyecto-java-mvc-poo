
package test.autoboxinunboxing;

public class TestAutoboxingUnboxing {

   
    public static void main(String[] args) {
        Integer entero = 10;
        System.out.println("entero = " + entero);
        System.out.println("entero: "+ entero.toString());
        System.out.println("entero = " + entero.doubleValue());
        
        int entero2 = entero;
        System.out.println("entero2 = " + entero2);
    }
    
}
