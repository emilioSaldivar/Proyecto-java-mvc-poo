
package com.emiliosaldivar.mundopc.bloquesdeinicializacion;

public class Persona {
    private final int idPersona;
    private static int contadorPersona;
    //bloques de inicializacion estaticos y no estaticos o dinamicos
    static{//solo variables estaticas son inicializadas y se ejecuta antes de los constructores se ejecuta
        //una vez y permanece en memoria
        
        System.out.println("Ejecucion bloque estatico");
        ++Persona.contadorPersona;//solo variables estaticas
    }
    {//bloque de inicializacion no estatico y se ejecuta antes del constructor y cada vez que se cree un objeto de tipo persona
        System.out.println("Ejecutando bloque no estatico");
        this.idPersona=Persona.contadorPersona++;
    }
    //constructores

    public Persona() {
        System.out.println("Ejecutando el bloque de construccion ");
    }
    
    //metodos

    public int getIdPersona() {
        return this.idPersona;
    }

    @Override
    public String toString() {
        return "Persona{" + "idPersona=" + idPersona + '}';
    }
    
    
    
}
