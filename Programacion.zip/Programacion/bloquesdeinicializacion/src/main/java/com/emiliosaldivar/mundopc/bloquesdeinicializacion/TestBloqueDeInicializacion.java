
package com.emiliosaldivar.mundopc.bloquesdeinicializacion;

public class TestBloqueDeInicializacion {

    
    public static void main(String[] args) {
        Persona persona1 = new Persona();
        System.out.println("persona1 = " + persona1);
        Persona persona2 = new Persona();
        System.out.println("\npersona1 = " + persona2);
        
    }
    
}
