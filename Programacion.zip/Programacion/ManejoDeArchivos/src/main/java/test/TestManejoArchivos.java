package test;

//import manejoarchivos.ManejoArchivos;
import static manejoarchivos.ManejoArchivos.*;

public class TestManejoArchivos {

    public static void main(String[] args) {
        String nombreArchivo = "prueba.txt";
        crearArchivo(nombreArchivo);

        escribirArchivo(nombreArchivo, "Emilio Saldivar el mejor loco es el");
        anexarArchivo(nombreArchivo, " obviamente es puretazo el ");
        leerArchivo(nombreArchivo);

    }

}
