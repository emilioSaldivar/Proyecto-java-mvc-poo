package aritmetica;

import exception.*;

public class Aritmetica {

    public static int division(int numerador, int denominador) throws OperationException{
            if (denominador == 0) {
            throw new OperationException("Division entre cero imposible aritmeticamente");
        }

        return numerador / denominador;
    }
}
