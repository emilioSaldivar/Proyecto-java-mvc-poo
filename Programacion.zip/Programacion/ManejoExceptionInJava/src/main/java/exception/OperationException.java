
package exception;


public class OperationException extends RuntimeException{
    public OperationException(String mensaje){
        super(mensaje);
    }
}
