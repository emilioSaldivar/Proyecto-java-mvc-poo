
package test;

import enumeracion.*;


public class TestEnumeraciones {

   
    public static void main(String[] args) {
        System.out.println("Dia: "+Dias.LUNES);
        System.out.println("Tercer continente del mundo: " +  Continentes.ASIA);
        System.out.println("Numero de paises dell tercer continente = " + Continentes.ASIA.getPaises());
    }
    private static void indicarDiaSemana(Dias dias){
        switch(dias){
            case DOMINGO:
                System.out.println("Primer dia de la semana\t");
                break;
            case LUNES:
                System.out.println("Segundo dia de la semana\t");
                break;
            case MARTES:
                System.out.println("Tercer dia de la semana\n");
                break;
            case MIERCOLES:
                System.out.println("Cuarto dia de la semana\t");
                break;
            case JUEVES:
                System.out.println("Quinto dia de la semana\t");
                break;
            case VIERNES:
                System.out.println("Sexto dia de la semana\t");
                break;
            case SABADO:
                System.out.println("Septimo dia de la semana\t");
                break;
                
        }
    }
}
