
package domain;

import java.io.Serializable;

public class PersonaBeans implements Serializable{
    //atributos
    private String nombre;
    private String apellido;
    //constructor
    public PersonaBeans(){
    }

    public PersonaBeans(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    //metodos
    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("PersonaBeans{nombre=").append(nombre);
        sb.append(", apellido=").append(apellido);
        sb.append('}');
        return sb.toString();
    }
    
    
}
