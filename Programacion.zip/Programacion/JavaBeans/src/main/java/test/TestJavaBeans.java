
package test;

import domain.PersonaBeans;


public class TestJavaBeans {

    public static void main(String[] args) {
        PersonaBeans persona = new PersonaBeans();
        persona.setNombre("emilio");
        persona.setApellido("saldivar");
        System.out.println(persona);
    }
    
}
