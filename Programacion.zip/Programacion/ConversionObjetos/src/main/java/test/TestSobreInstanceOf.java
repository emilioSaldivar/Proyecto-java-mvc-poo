package test;

import domain.sobreescritura.Empleado;
import domain.sobreescritura.Gerente;

public class TestSobreInstanceOf {

    public static void main(String[] args) {
        
        Empleado empleado = new Empleado("emilio jeyma", 100000);
        empleado = new Gerente("emilio", 50000, "Tecnologia E Informacion");
        determinarTipo(empleado);
    }

    public static void determinarTipo(Empleado empleado) {
        if (empleado instanceof Gerente){
            System.out.println("Es de tipo gerente");
            Gerente gerente = (Gerente) empleado;
            System.out.println("Puesto del empleado es"+ gerente.getDepartamento());
            
        }else if (empleado instanceof Empleado){
            System.out.println("Es de tiopo empleado");
        }
    }
}
