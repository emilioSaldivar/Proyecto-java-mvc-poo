
package domain.interfaces;

public interface IAccesoDatos {
    //atributos siempre son constantes
    int MAXIMO_REGISTROS = 10;
    //metodos
    void insertar();
    
    void listar();
    
    void actualizar();
    
    void eliminar();
    
}
