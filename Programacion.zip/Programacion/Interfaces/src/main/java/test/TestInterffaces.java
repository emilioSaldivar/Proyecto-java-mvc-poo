
package test;

import domain.interfaces.*;

public class TestInterffaces {

    public static void main(String[] args) {
        IAccesoDatos datos = new ImplementacionMySQL();
        datos.listar();
        datos = new ImplementacionOracle();
        datos.listar();
    }
    
}
