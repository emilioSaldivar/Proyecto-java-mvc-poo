
package test;

import java.util.*;

public class TestColecciones {

    public static void main(String[] args) {
        List miLista = new ArrayList ();
        
        miLista.add("LUNES");
        miLista.add("MARTES");
        miLista.add("MIERCOLES");
        miLista.add("JUEVES");
        miLista.add("VIERNES");
        miLista.add("SABADO");
        miLista.add("DOMINGO");
        
        imprimir(miLista);
        
        Set miSet = new HashSet();
        
        miSet.add("EMILIO ");
        miSet.add("MATIAS ");
        miSet.add("JULIO");
        miSet.add("JULLITO ");
        miSet.add("ROBERTO ");
        miSet.add("OSCAR ");
        
        imprimir(miSet);
        
        Map miMapa = new HashMap();
        miMapa.put("valor1", "emilio");
        miMapa.put("valor2", "emilio matias");
        miMapa.put("valor3", "emilio matias saldivar");
        miMapa.put("valor4", "emilio matias saldivar caputo");
        miMapa.put("valor5", "emilio matias saldivar caputo el mejor");
        miMapa.put("valor6", "emilio matias saldivar caputo el mejor de todos los mejores del planeta kape loco");
        
        String elementoDelMapa = (String) miMapa.get("valor1");
        System.out.println("elementoDelMapa = " + elementoDelMapa);
        imprimir(miMapa.keySet());
        imprimir(miMapa.values());
    }
    public static void imprimir(Collection coleccion){
        coleccion.forEach(elemento -> {
            System.out.println("colecion = " + elemento);
        });
    }
}
