package test;

import conversiondeobjetos.*;
import conversiondeobjetos.TipoEscritura;

public class TesConversionDeObjetos {

    public static void main(String[] args) {
        
        Empleado empleado;
        empleado = new Escritor("emilio saldivar el mejor", 5000000, TipoEscritura.MODERNO);
        
        System.out.println("los detalles" + empleado.obtenerDetalles());
        
    }

   
}
