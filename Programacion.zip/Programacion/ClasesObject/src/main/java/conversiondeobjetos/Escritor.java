
package conversiondeobjetos;


public class Escritor extends Empleado{
    final TipoEscritura tipoDeEscritura;
    
    public Escritor(String nombre, double sueldo, TipoEscritura tipoDeEscritura){
        super(nombre,sueldo);
        this.tipoDeEscritura = tipoDeEscritura;
    }
    
    @Override
    public String obtenerDetalles(){
        return super.obtenerDetalles() + ", tipo de escritura: " + this.tipoDeEscritura;
    }
    
}
