
package domain.clasesabstractas;


public class Rctangulo extends FiguraGeometrica{
    
    public Rctangulo(String tipoFigura) {
        super(tipoFigura);
    }
    
    @Override
    public void dibujar(){
        System.out.println("La figura que se imprime es: " +  this.getClass().getSimpleName());
    }
}
