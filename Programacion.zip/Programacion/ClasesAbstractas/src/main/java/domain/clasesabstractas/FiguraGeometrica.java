
package domain.clasesabstractas;

public abstract class FiguraGeometrica {
    //atributos
    protected String tipoDeFigura;
    //constructorr
    protected FiguraGeometrica(String tipoDeFigura){
        this.tipoDeFigura = tipoDeFigura;
    }
    //metodos
    public abstract void dibujar();

    public String getTipoDeFigura() {
        return this.tipoDeFigura;
    }

    public void setTipoDeFigura(String tipoDeFigura) {
        this.tipoDeFigura = tipoDeFigura;
    }

    @Override
    public String toString() {
        return "FiguraGeometrica{" + "tipoDeFigura=" + tipoDeFigura + '}';
    }
    
    
    
}
