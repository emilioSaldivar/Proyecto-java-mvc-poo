
package test;

import domain.clasesabstractas.*;


public class TestClasesAbstractas {

   
    public static void main(String[] args) {
        FiguraGeometrica figura = new Rctangulo("Rectangulo ");
        figura.dibujar();
    }
    
}
