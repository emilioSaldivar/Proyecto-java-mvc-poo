
package test;

import conversiondeobjetos.*;


public class TestClasesObject {

   
    public static void main(String[] args) {
       Empleado empleado1 = new Empleado ("emilio saldivar", 500000);
       Empleado empleado2 = new Empleado ("matias caputo", 6000000);
       Empleado empleado3 = new Empleado ("emilio saldivar", 500000);
       
       if (empleado1 == empleado2){
           System.out.println("Tienen la misma referencia en memoria");
       }
       else {
           System.out.println("No tienen la misma referencia en memoria");
       }
       
       if(empleado1.equals(empleado2)){
           System.out.println("Los objetos son iguales en contenido");
       }else{
           System.out.println("Los objetos difierren en contenido");
       }
       if (empleado1.hashCode()==empleado3.hashCode()){
           System.out.println("Los empleados tienen mismo nombre y mismo sueldo");
       }
       else {
           System.out.println("Los objetos comparados no son iguales ");
       }
    }
    
}
