package test;

import domain.sobreescritura.Empleado;
import domain.sobreescritura.Gerente;

public class TestSobreEscrituraDeMetodos {

    public static void main(String[] args) {
        Gerente gerente1 = new Gerente("emilio", 50000, "Tecnologia E Informacion");
        System.out.println("La info completa del empleado es: \n" + gerente1.obtenerDetalles());
        Empleado empleado = new Empleado("emilio jeyma", 100000);
        System.out.println("empleado = " + empleado.obtenerDetalles());
        imprimir(gerente1);
        imprimir(empleado);
    }

    public static void imprimir(Empleado empleado) {
        System.out.println("empleado = " + empleado.obtenerDetalles());
    }
}
